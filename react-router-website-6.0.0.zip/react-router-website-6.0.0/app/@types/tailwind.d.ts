import type { TailwindConfig } from "tailwindcss/tailwind-config";
export const theme: TailwindConfig["theme"];
export const tailwindConfig: TailwindConfig;
