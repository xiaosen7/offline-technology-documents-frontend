declare module "use-throttle" {
  export function useThrottle<V>(value: V, limit: number): V;
}
