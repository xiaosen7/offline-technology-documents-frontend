module.exports = {
  plugins: {
    tailwindcss: {},
    "postcss-import": {},
    "postcss-nesting": {},
    "postcss-100vh-fix": {},
    "postcss-focus-visible": {},
  },
};
